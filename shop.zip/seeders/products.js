
const Product = require('../models/Product');
const Subcategory = require('../models/Subcategory');

const products = [
  { name: 'MacBook Pro', subcategory: null }, 
  { name: 'Plain White Tee', subcategory: null },
];

const seedProducts = async () => {
  try {
    await Product.deleteMany({});
    const subcategories = await Subcategory.find({});

    for (const product of products) {
      const subcategory = subcategories.find((s) => s.name === product.name);
      product.subcategory = subcategory._id;
    }

    await Product.insertMany(products);
    console.log('Products seeded successfully');
  } catch (err) {
    console.error(err);
  }
};

module.exports = seedProducts;
