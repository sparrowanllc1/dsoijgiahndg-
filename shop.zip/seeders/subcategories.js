
const Subcategory = require('../model/submenu.model');
const Category = require('../model/menu.model');

const subcategories = [
  { name: 'Laptops', category: null }, 
  { name: 'T-Shirts', category: null },
];

const seedSubcategories = async () => {
  try {
    await Subcategory.deleteMany({});
    const mainCategories = await Category.find({});

    for (const subcategory of subcategories) {
      const category = mainCategories.find((c) => c.name === subcategory.name);
      subcategory.category = category._id;
    }

    await Subcategory.insertMany(subcategories);
    console.log('Subcategories seeded successfully');
  } catch (err) {
    console.error(err);
  }
};

module.exports = seedSubcategories;
