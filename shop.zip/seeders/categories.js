
const Category = require('../model/menu.model');

const categories = [
  { name: 'Electronics' },
  { name: 'Clothing' },
];

const seedCategories = async () => {
  try {
    await Category.deleteMany({});
    await Category.insertMany(categories);
    console.log('Categories seeded successfully');
  } catch (err) {
    console.error(err);
  }
};

module.exports = seedCategories;
