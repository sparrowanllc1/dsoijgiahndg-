
const express = require('express');
const router = express.Router();
const Subcategory = require('../model/submenu.model');

const getSubcategoriesByCategory = async (req, res) => {
  try {
    const { categoryId } = req.params;
    const subcategories = await Subcategory.find({ category: categoryId });
    res.render('subcategories', { subcategories });
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
};

router.get('/:categoryId', getSubcategoriesByCategory);

module.exports = router;
