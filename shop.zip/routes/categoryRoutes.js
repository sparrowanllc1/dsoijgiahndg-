
const express = require('express');
const router = express.Router();
const Category = require('../model/menu.model');

const getCategories = async (req, res) => {
  try {
    const categories = await Category.find();
    res.render('categories', { categories });
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
};

const updateCategory = async (req, res) => {
  try {
    const { categoryId } = req.params;
    const { newName } = req.body;
    const updatedCategory = await Category.findByIdAndUpdate(categoryId, { name: newName }, { new: true });
    res.status(200).json(updatedCategory);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
};

router.get('/', getCategories);
router.put('/:categoryId', updateCategory);

module.exports = router;
