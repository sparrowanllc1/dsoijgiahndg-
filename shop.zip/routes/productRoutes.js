
const express = require('express');
const router = express.Router();
const Product = require('../model/product.model');

const getProductsBySubcategory = async (req, res) => {
  try {
    const { subcategoryId } = req.params;
    const products = await Product.find({ subcategory: subcategoryId });
    res.render('products', { products });
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// Register routes
router.get('/:subcategoryId', getProductsBySubcategory);

module.exports = router;
